package com.shridhar.androidclass

import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val welcomeText: TextView = findViewById(R.id.welcome_text)
        val email: EditText = findViewById(R.id.email) // Ctrl + D to duplicate
        val password: EditText = findViewById(R.id.password)
        val button: Button = findViewById(R.id.button)

        button.setOnClickListener {
            welcomeText.text = "This is a changed text"

            var emailText = email.text.toString()
            var passwordText = password.text.toString()

            if (TextUtils.isEmpty(emailText)) {
                Toast.makeText(this, "Email cannot be empty", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (TextUtils.isEmpty(passwordText)) {
                Toast.makeText(this, "Password cannot be empty", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            // Toast
            Toast.makeText(this, emailText, Toast.LENGTH_LONG).show()

            println(emailText)
        }

    }
}